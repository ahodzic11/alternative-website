const { createWorkshop, getWorkshops, getWorkshopByName } = require("./workshopController");
const router = require("express").Router();

router.post("/", createWorkshop);
router.get("/", getWorkshops);
router.get("/:name", getWorkshopByName);

module.exports = router;
