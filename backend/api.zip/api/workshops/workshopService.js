const pool = require("../../config/database");

module.exports = {
  create: (data, callBack) => {
    pool.query(
      `INSERT INTO workshops(naslov, mjesto, datum, trener, ucesnici, nazivDonatora, nazivProjekta, cilj, opisRadionice) 
        values(?,?,?,?,?,?,?,?,?)`,
      [data.naslov, data.mjesto, data.datum, data.trener, data.ucesnici, data.nazivDonatora, data.nazivProjekta, data.cilj, data.opisRadionice],
      (error, results, fields) => {
        if (error) {
          return callBack(error);
        }
        return callBack(null, results);
      }
    );
  },

  getWorkshops: (callBack) => {
    pool.query(`SELECT * FROM workshops`, [], (error, results, fields) => {
      if (error) {
        return callBack(error);
      }
      return callBack(null, results);
    });
  },

  getWorkshopByName: (name, callBack) => {
    pool.query(`SELECT * FROM workshops WHERE naslov = ?`, [name], (error, results, fields) => {
      if (error) {
        return callBack(error);
      }
      return callBack(null, results[0]);
    });
  },
};
