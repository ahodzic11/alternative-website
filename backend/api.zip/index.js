require("dotenv").config();
var cors = require("cors");
const express = require("express");
const app = express();
app.use(cors());
const userRouter = require("./api/users/userRouter");
const workshopRouter = require("./api/workshops/workshopRouter");

app.use(express.json());

app.use("/api/users", userRouter);
app.use("/api/workshops", workshopRouter);

app.listen();

/*
5000, () => {
  console.log("Server up and running on port", 5000);
}*/
